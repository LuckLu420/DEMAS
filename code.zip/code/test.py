import argparse
import json
import os
# os.system('pip install -r ./requirement.txt')
import random

import numpy as np
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm
from transformers import BartTokenizer
from transformers import ViTImageProcessor

from dataset import MMSSDataset
from scorer import rouge_score


def post_process(hypothesis):
    hypothesis = hypothesis.replace('<s>', '')
    hypothesis = hypothesis.replace('<pad>', '')
    hypothesis = hypothesis.replace('</s>', '')
    hypothesis = hypothesis.replace("'s", " 's")
    hypothesis = hypothesis.strip()
    return hypothesis


@torch.no_grad()
def test(args, test_batch, model, tokenizer):

    hypotheses = []
    for step, inputs in tqdm(enumerate(test_batch), total=len(test_batch)):

        inputs = [t.to(args.device) for t in inputs]

        (pixel_values,
         sentence_input_ids, sentence_attention_mask,
         summarization_input_ids, summarization_attention_mask,
         labels,
         domain_ids) = inputs

        model.eval()
        generated_ids = model.generate(
            pixel_values=pixel_values,
            sentence_input_ids=sentence_input_ids,
            sentence_attention_mask=sentence_attention_mask,
            domain_ids=domain_ids,
        )

        generated_summarization = tokenizer.batch_decode(
            generated_ids, skip_special_tokens=False
        )
        hypotheses += generated_summarization


    post_process_hypotheses = [post_process(hyp) for hyp in hypotheses]


    test_texts_file_path = os.path.join(args.dataset_path, 'test', 'texts.json')
    with open(file=test_texts_file_path, mode='r', encoding='utf-8') as test_texts_file:
        test_texts = json.load(fp=test_texts_file)

    test_texts = test_texts[:round(args.test_dataset_proportion * len(test_texts))]


    for tt, pph in zip(test_texts, post_process_hypotheses):
        tt['generated summarization'] = pph


    val_rouge_score = evaluate(args=args, val_batch=test_batch, model=model, tokenizer=tokenizer)
    val_rouge_1 = val_rouge_score['rouge-1']['f']
    val_rouge_2 = val_rouge_score['rouge-2']['f']
    val_rouge_l = val_rouge_score['rouge-l']['f']
    print("r1 r2 rouge-l", val_rouge_1, val_rouge_2, val_rouge_l)

    return test_texts


@torch.no_grad()
def evaluate(args, val_batch, model, tokenizer):

    hypotheses = []
    for step, inputs in tqdm(enumerate(val_batch), total=len(val_batch)):
        inputs = [t.to(args.device) for t in inputs]

        (pixel_values,
         sentence_input_ids, sentence_attention_mask,
         summarization_input_ids, summarization_attention_mask,
         labels,
         domain_ids) = inputs

        model.eval()
        generated_ids = model.generate(
            pixel_values=pixel_values,
            sentence_input_ids=sentence_input_ids,
            sentence_attention_mask=sentence_attention_mask,
            domain_ids=domain_ids,
        )

        generated_summarization = tokenizer.batch_decode(
            generated_ids, skip_special_tokens=False
        )
        hypotheses += generated_summarization

    post_process_hypotheses = [post_process(hyp) for hyp in hypotheses]

    references = []
    val_texts_file_path = os.path.join(args.dataset_path, 'test', 'texts.json')
    with open(file=val_texts_file_path, mode='r', encoding='utf-8') as val_texts_file:
        val_texts = json.load(fp=val_texts_file)

    val_texts = val_texts[:round(args.test_dataset_proportion * len(val_texts))]

    for vt in val_texts:
        references.append(vt['summarization'])

    return rouge_score(hypotheses=post_process_hypotheses, references=references)


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument('--seed', type=int, default=1)

    parser.add_argument('--dataset_path', type=str, default='/ai/ld/datasets/mmss-1/')
    parser.add_argument('--vision_foundation_model', type=str, default='/ai/ld/pretrain/vit-base-patch32-224-in21k/')
    parser.add_argument('--language_foundation_model', type=str, default='/ai/ld/pretrain/bart-base/')

    parser.add_argument('--max_sentence_length', type=int, default=55)
    parser.add_argument('--max_summarization_length', type=int, default=30)

    parser.add_argument('--test_dataset_proportion', type=float, default=1.0)

    parser.add_argument('--evaluate_batch_size', type=int, default=16)

    parser.add_argument('--num_beams', type=int, default=10)

    return parser.parse_args()


def main():
    args = parse_args()

    args.device = torch.device('cuda')


    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.deterministic = True

    image_processor = ViTImageProcessor.from_pretrained(
        pretrained_model_name_or_path=args.vision_foundation_model
    )
    tokenizer = BartTokenizer.from_pretrained(
        pretrained_model_name_or_path=args.language_foundation_model
    )

    test_dataset_path = os.path.join(args.dataset_path, 'test')
    test_dataset = MMSSDataset(
        dataset_path=test_dataset_path,
        image_processor=image_processor,
        tokenizer=tokenizer,
        max_sentence_length=args.max_sentence_length,
        max_summarization_length=args.max_summarization_length,
        proportion=args.test_dataset_proportion
    )
    test_batch = DataLoader(
        dataset=test_dataset,
        batch_size=args.evaluate_batch_size,
        shuffle=False
    )

    best_model_path = 'best_model.pt'

    best_model = torch.load(f=best_model_path, map_location=args.device)
    best_model = best_model.to(args.device)
    best_model.eval()

    test_texts = test(
        args=args,
        test_batch=test_batch,
        model=best_model,
        tokenizer=tokenizer
    )

    with open('./test.json', mode='w', encoding='utf-8') as write_file:
        json.dump(obj=test_texts, fp=write_file, ensure_ascii=False, indent=4)


if __name__ == '__main__':
    main()
